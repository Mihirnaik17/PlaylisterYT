import { useContext } from 'react';
import AuthContext from '../auth'
import MUIErrorModal from './MUIErrorModal'

import Avatar from '@mui/material/Avatar';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Container from '@mui/material/Container';
import CssBaseline from '@mui/material/CssBaseline';
import Link from '@mui/material/Link';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import TextField from '@mui/material/TextField';
import Typography from '@mui/material/Typography';

export default function LoginScreen() {
    const { auth } = useContext(AuthContext);

    const handleSubmit = (event) => {
        event.preventDefault();
        const formData = new FormData(event.currentTarget);
        auth.loginUser(
            formData.get('email'),
            formData.get('password')
        );

    };

    let modalJSX = "";
    console.log(auth);
    if (auth.errorMessage !== null){
        modalJSX = <MUIErrorModal />;
    }
    console.log(modalJSX);

    return (
        <Box sx={{ height: '100vh', bgcolor: '#f0e6f6' }}>
            <Box
                sx={{
                    height: '60px',
                    bgcolor: '#FF00FF',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    px: 2
                }}
            >
                <Box 
                    onClick={() => window.location.href = '/'} 
                    sx={{ color: 'white', fontSize: '24px', cursor: 'pointer' }}
                    >
                    🏠
                </Box>
                <Box sx={{ color: 'white', fontSize: '24px', cursor: 'pointer' }}>👤</Box>
            </Box>

            <Container component="main" maxWidth="xs">
                <CssBaseline />
                <Box
                    sx={{
                        marginTop: 8,
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        bgcolor: '#FFFACD',
                        padding: 4,
                        borderRadius: 2,
                        border: '2px solid #000'
                    }}
                >
                    <Avatar sx={{ m: 1, bgcolor: '#9C27B0' }}>
                        <LockOutlinedIcon/>
                    </Avatar>
                    <Typography component="h1" variant="h5" sx={{ mb: 3 }}>
                        Sign In
                    </Typography>
                    <Box component="form" noValidate onSubmit={handleSubmit} sx={{ width: '100%' }}>
                        <TextField
                            margin="normal"
                            required
                            fullWidth
                            id="email"
                            label="Email"
                            name="email"
                            autoComplete="email"
                            autoFocus
                            sx={{ bgcolor: '#E8E8E8' }}
                        />
                        <TextField
                            margin="normal"
                            required
                            fullWidth
                            name="password"
                            label="Password"
                            type="password"
                            id="password"
                            autoComplete="current-password"
                            sx={{ bgcolor: '#E8E8E8' }}
                        />
                        <Button
                            type="submit"
                            fullWidth
                            variant="contained"
                            sx={{ 
                                mt: 3, 
                                mb: 2,
                                bgcolor: '#333',
                                color: '#fff',
                                '&:hover': { bgcolor: '#555' }
                            }}
                        >
                            SIGN IN
                        </Button>
                        <Box sx={{ textAlign: 'center' }}>
                            <Link href="/register/" variant="body2" sx={{ color: 'red' }}>
                                Don't have an account? Sign Up
                            </Link>
                        </Box>
                        <Typography variant="body2" color="text.secondary" align="center" sx={{ mt: 3 }}>
                            Copyright © Playlister 2025
                        </Typography>
                    </Box>
                </Box>
            </Container>
            { modalJSX }
        </Box>
    );
}